The supplementary material illustrates the performance of our algorithm 
on high-resolution images. It also illustrates the evolution of the 
superpixels on a sample image and includes our code.

The TIF files contain results of running the TurboPixel algorithm on 
high-resolution images. The number after the underscore indicates the 
number of seeds used.

superpixels.avi illustrates the evolution of the superpixels

TurboPixels directory contains the code of our algorithm. There is a
README.txt file inside it explaining how to use the code.